#!/usr/bin/env bash
set -euo pipefail

# =========================
# 設定
# =========================
SRC_ISO="/home/user/Desktop/VMware-VMvisor-Installer-8.0U1a-21813344.x86_64.iso"
WORK_DIR="/home/user/esxi"
ISO_MATERIAL_DIR="/home/user/Desktop/iso_material/esxi_03"
OUTPUT_ISO="/home/user/Desktop/esxi_03.iso"

KS_CFG_SRC="${ISO_MATERIAL_DIR}/ks.cfg"
BOOT_CFG_SRC="${ISO_MATERIAL_DIR}/boot.cfg"

# =========================
# 事前チェック
# =========================
echo "▶ 事前チェック中..."

[ -f "$SRC_ISO" ] || { echo "❌ 元ISOが存在しません: $SRC_ISO"; exit 1; }
[ -f "$KS_CFG_SRC" ] || { echo "❌ ks.cfg が存在しません: $KS_CFG_SRC"; exit 1; }
[ -f "$BOOT_CFG_SRC" ] || { echo "❌ boot.cfg が存在しません: $BOOT_CFG_SRC"; exit 1; }

# =========================
# 作業ディレクトリ作成
# =========================
echo "▶ 作業ディレクトリ作成: $WORK_DIR"
rm -rf "$WORK_DIR"
mkdir -p "$WORK_DIR"

# =========================
# ISO 展開（マウント不要）
# =========================
echo "▶ ISO 展開中..."
xorriso -osirrox on \
  -indev "$SRC_ISO" \
  -extract / "$WORK_DIR"

# =========================
# Kickstart / boot.cfg コピー
# =========================
echo "▶ ks.cfg / boot.cfg コピー..."
cp "$KS_CFG_SRC" "$WORK_DIR/KS.CFG"
cp "$BOOT_CFG_SRC" "$WORK_DIR/EFI/BOOT/BOOT.CFG"

# =========================
# ISO 再作成
# =========================
echo "▶ ISO 再作成中..."
xorriso -as mkisofs \
  -relaxed-filenames \
  -J -R \
  -o "$OUTPUT_ISO" \
  -b ISOLINUX.BIN \
  -c BOOT.CAT \
  -no-emul-boot \
  -boot-load-size 4 \
  -boot-info-table \
  -eltorito-alt-boot \
  -e EFIBOOT.IMG \
  -no-emul-boot \
  "$WORK_DIR"

echo "✅ 完了: $OUTPUT_ISO"
