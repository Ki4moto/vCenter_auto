#!/usr/bin/env bash
set -euo pipefail

# ===== 設定 =====
SRC_ISO="/home/user/Desktop/SERVER_EVAL_x64FRE_ja-jp.iso"
WORK_DIR="/home/user/win"
AUTO_XML="/home/user/Desktop/iso_material/win_01/autounattend.xml"
OUTPUT_ISO="/mnt/nfs_share/win_01/win_01.iso"
VOLID="CCCOMA_X64FRE_JA-JP_DV9"

# ===== 事前チェック =====
if [ ! -f "$SRC_ISO" ]; then
  echo "❌ 元のISOが見つかりません: $SRC_ISO"
  exit 1
fi

if [ ! -f "$AUTO_XML" ]; then
  echo "❌ autounattend.xml が見つかりません: $AUTO_XML"
  exit 1
fi

# ===== 作業ディレクトリ作成 =====
echo "📁 作業ディレクトリ作成: $WORK_DIR"
mkdir -p "$WORK_DIR"

# ===== ISO 展開 =====
echo "📦 ISO を展開中..."
7z x "$SRC_ISO" -o"$WORK_DIR"

# ===== autounattend.xml 配置 =====
echo "📄 autounattend.xml をコピー"
cp "$AUTO_XML" "$WORK_DIR/"

# ===== ISO 再作成 =====
echo "💿 ISO を再作成中..."
xorriso -as mkisofs \
  -iso-level 3 \
  -full-iso9660-filenames \
  -joliet \
  -volid "$VOLID" \
  -eltorito-boot efi/microsoft/boot/cdboot_noprompt.efi \
  -no-emul-boot \
  -boot-load-size 8 \
  -boot-info-table \
  -eltorito-alt-boot \
  -e efi/microsoft/boot/efisys_noprompt.bin \
  -no-emul-boot \
  -isohybrid-gpt-basdat \
  -o "$OUTPUT_ISO" \
  "$WORK_DIR"

echo "✅ ISO 作成完了: $OUTPUT_ISO"
